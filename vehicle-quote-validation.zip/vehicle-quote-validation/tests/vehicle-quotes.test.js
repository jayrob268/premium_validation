import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import path from 'path';
import { runVehicleQuote } from '../src/flows/vehicleQuoteFlow.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const scenarios = JSON.parse(
  readFileSync(path.join(__dirname, '../src/data/converted/scenarios.json'), 'utf8')
);

fixture('Vehicle quotes')
  .page(process.env.BASE_URL || 'https://quote-env.example.com');

// One TestCafe test per spreadsheet row.
// Premium comparison is a placeholder until the premium validator is written.
for (const scenario of scenarios) {
  test(`Quote ${scenario['QuoteID']} (test_id ${scenario['test_id']})`, async (t) => {
    const result = await runVehicleQuote(t, scenario);
    await t.expect(result.premiumText).notEql('', 'premium was empty');
  });
}
