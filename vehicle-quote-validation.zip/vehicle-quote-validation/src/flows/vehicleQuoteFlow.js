import { VehicleDetailsPage } from '../pages/VehicleDetailsPage.js';
import { DriverDetailsPage } from '../pages/DriverDetailsPage.js';
import { CoverOptionsPage } from '../pages/CoverOptionsPage.js';
import { QuoteSummaryPage } from '../pages/QuoteSummaryPage.js';

/**
 * Runs one scenario row through the vehicle quote journey.
 * Returns what the UI showed, as text, for the validators to check.
 */
export async function runVehicleQuote(t, scenario) {
  // TODO: confirm the page order matches the live journey
  await new VehicleDetailsPage(t).fillFrom(scenario);
  await new DriverDetailsPage(t).fillFrom(scenario);
  await new CoverOptionsPage(t).fillFrom(scenario);

  const summary = new QuoteSummaryPage(t);
  return {
    quoteId: scenario['QuoteID'],
    premiumText: await summary.readPremium(),
    excessText: await summary.readExcess(),
  };
}
