import { BasePage } from './BasePage.js';

// TODO: replace every selector with the real one from the vehicle details screen
const SEL = {
  make: '#vehicle-make',
  group: '#vehicle-group',
  age: '#vehicle-age',
  ageWhenBought: '#vehicle-age-bought',
  value: '#vehicle-value',
  fuelType: '#fuel-type',
  transmission: '#transmission',
  doors: '#number-of-doors',
  engineCc: '#engine-cc',
  mileage: '#mileage',
  leftHandDrive: '#left-hand-drive',
  imported: '#imported',
  taxed: '#currently-taxed',
  nct: '#currently-nct',
  previousOwners: '#previous-owners',
};

export class VehicleDetailsPage extends BasePage {
  async fillFrom(s) {
    await this.choose(SEL.make, s['Vehicle Make']);
    await this.choose(SEL.group, s['Vehicle Group']);
    await this.fill(SEL.age, s['Vehicle Age']);
    await this.fill(SEL.ageWhenBought, s['Vehicle Age when Bought']);
    await this.fill(SEL.value, s['Vehicle Value']);
    await this.choose(SEL.fuelType, s['Fuel Type']);
    await this.choose(SEL.transmission, s['Transmission']);
    await this.choose(SEL.doors, s['Number of Doors']);
    await this.fill(SEL.engineCc, s['Engine CC']);
    await this.fill(SEL.mileage, s['Mileage']);
    await this.tickIf(SEL.leftHandDrive, s['Left Hand Drive']);
    await this.tickIf(SEL.imported, s['Import']);
    await this.tickIf(SEL.taxed, s['Currently Taxed']);
    await this.tickIf(SEL.nct, s['Currently NCT']);
    await this.fill(SEL.previousOwners, s['Number of Previous Owners']);
    await this.next();
  }
}
