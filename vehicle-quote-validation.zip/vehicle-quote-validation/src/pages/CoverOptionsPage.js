import { BasePage } from './BasePage.js';

// TODO: replace with the real selectors from the cover options screen
const SEL = {
  cover: '#cover-type',
  voluntaryExcess: '#voluntary-excess',
  windscreen: '#windscreen-cover',
  openDriving: '#open-driving',
  thirdPartyOtherCars: '#tp-other-cars',
  comprehensiveOtherCars: '#comp-other-cars',
  replacementCar: '#replacement-car',
  injuryToDriver: '#injury-to-driver',
  breakdown: '#breakdown-assistance',
  personalBelongings: '#personal-belongings',
};

export class CoverOptionsPage extends BasePage {
  async fillFrom(s) {
    await this.choose(SEL.cover, s['Cover']);
    await this.choose(SEL.voluntaryExcess, s['Voluntary Excess']);
    await this.tickIf(SEL.windscreen, s['Windsreen/Glass Breakage']);
    await this.tickIf(SEL.openDriving, s['Open Driving']);
    await this.tickIf(SEL.thirdPartyOtherCars, s['Third Party Driver Other Cars']);
    await this.tickIf(SEL.comprehensiveOtherCars, s['Comprehensive Drive Other Cars']);
    await this.tickIf(SEL.replacementCar, s['Replacement Car']);
    await this.tickIf(SEL.injuryToDriver, s['Injury to Driver']);
    await this.tickIf(SEL.breakdown, s['Breakdown Assistance']);
    await this.tickIf(SEL.personalBelongings, s['Personal Belongings']);
    await this.next();
  }
}
