import { BasePage } from './BasePage.js';

// TODO: replace with the real selectors from the driver screen
const SEL = {
  age: '#main-driver-age',
  licenceYears: '#licence-years',
  provisional: '#provisional-licence',
  country: '#country-of-licence',
  penaltyPoints: '#penalty-points',
  employment: '#employment-status',
  occupation: '#occupation',
  partTimeOccupation: '#part-time-occupation',
  workFromHome: '#work-from-home',
  homeowner: '#homeowner',
  previousInsurance: '#previous-insurance',
  claimsFreeYears: '#claims-free-years',
  ncd: '#ncd',
  protectedNcd: '#protected-ncd',
  eircode: '#eircode',
  smallArea: '#small-area',
  paymentMethod: '#payment-method',
};

export class DriverDetailsPage extends BasePage {
  async fillFrom(s) {
    await this.fill(SEL.age, s['Age']);
    await this.fill(SEL.licenceYears, s['Licence Years']);
    await this.tickIf(SEL.provisional, s['Provisional Licence']);
    await this.choose(SEL.country, s['Country of Licence']);
    await this.fill(SEL.penaltyPoints, s['Penalty Points']);
    await this.choose(SEL.employment, s['Employment Status']);
    await this.choose(SEL.occupation, s['Occupation']);
    await this.choose(SEL.partTimeOccupation, s['Part-Time Occupation']);
    await this.tickIf(SEL.workFromHome, s['Work from Home']);
    await this.tickIf(SEL.homeowner, s['Homeowner']);
    await this.fill(SEL.eircode, s['Eircode']);
    await this.fill(SEL.smallArea, s['Small Area']);
    await this.choose(SEL.previousInsurance, s['Previous Insurance']);
    await this.fill(SEL.claimsFreeYears, s['Claims Free Years']);
    await this.fill(SEL.ncd, s['NCD']);
    await this.tickIf(SEL.protectedNcd, s['Protected NCD']);
    await this.choose(SEL.paymentMethod, s['Payment Method']);
    await this.next();
  }
}
