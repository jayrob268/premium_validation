import { Selector } from 'testcafe';
import { BasePage } from './BasePage.js';

// TODO: replace with the real selectors from the quote summary screen
const SEL = {
  premium: '[data-test="annual-premium"]',
  excess: '[data-test="excess"]',
};

export class QuoteSummaryPage extends BasePage {
  // Returns the displayed premium as text. Parsing and comparison happen in the validators.
  async readPremium() {
    return Selector(SEL.premium).innerText;
  }

  async readExcess() {
    return Selector(SEL.excess).innerText;
  }
}
